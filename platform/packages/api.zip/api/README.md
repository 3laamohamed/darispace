# Docs

Laravel Sanctum official docs: https://laravel.com/docs/sanctum

# Available API

- See the list in `http://your-domain.com/docs/index.html`

# Generate API docs
- php artisan scribe:generate
