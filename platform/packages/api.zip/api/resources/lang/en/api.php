<?php

return [
    'settings' => 'API Settings',
    'save_settings' => 'Save settings',
    'setting_title' => 'API settings',
    'setting_description' => 'Settings for API',
    'api_enabled' => 'API enabled?',
];
