<?php

return [
    [
        'name' => 'API settings',
        'flag' => 'api.settings',
        'parent_flag' => 'settings.options',
    ],
];
